from distutils.core import setup

# Функция установки
setup(name="MaterialDegradation",
      version="1.0",
      author="Igor Starostin",
      author_email="starostinigo@yandex.ru",
      description="Material degradation modeling",
      packages=["MaterialDegradation"]
      )
